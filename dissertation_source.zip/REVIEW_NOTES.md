# Dissertation review report

This is a findings-only audit. The broad editorial and proof rewrites from the
first review pass have been rolled back. The manuscript keeps the author's
wording and substantive arguments. Only bibliography/citation corrections and
narrow mechanical notation, index, delimiter, label, and cross-reference fixes
remain.

## Build and reference status

- Main file: dissertation.tex
- Output: dissertation.pdf, 92 pages
- Forced latexmk/pdfLaTeX/BibTeX build: successful
- Undefined references or citations: none
- Distinct cited bibliography keys: 37; all are present in references.bib
- Unique labels: 38; no undefined or multiply-defined labels
- BibTeX warnings: none
- Underfull boxes: none reported
- Accidental adjacent repeated prose words: none found. Regex hits such as
  "a a-top", "p p-top", and "C c" are mathematical expressions, not prose
  repetitions.

The restored manuscript has five overfull boxes:

- related_work.tex:30--32: 5.7222 pt
- FOSP_eggroll.tex:357--358: 6.88132 pt
- linear_mixing.tex:306: 28.5644 pt
- linear_mixing.tex:323: 10.91226 pt
- linear_mixing.tex:359: 45.7496 pt

## Drafting markers and residual placeholders

- dissertation.tex:7 and :12 retain the title-page word-count TODO.
- FOSP_eggroll.tex:43 and :85 still call the chapter an "excerpt."
- FOSP_eggroll.tex:499 refers to hard-coded "Theorem 3" rather than a label.
- No FIXME, XXX, TBD, lorem ipsum, or explicit PLACEHOLDER marker was found in
  the active include tree.

## Bibliography and reference fixes retained

- Corrected the two broken half-two-gradient references in FOSP_eggroll.tex.
- Normalized textual and parenthetical natbib commands where the original
  syntax produced malformed author-year prose.
- Protected significant title capitalization in references.bib:
  SubGaussian, Nesterov, NP, O(1/k^2), Newton, Tikhonov, and Bayesian.
- Removed the number field from seung2026lowrank because plainnat ignores it
  when volume is also present.
- Retained consistent lem: label prefixes and equation references where needed.

## Mathematical and logical holes requiring author review

### Introduction, related work, and conclusion

- introduction.tex:42 describes the mirror-descent result as applying to
  "convex rho-Lipschitz quadratic functions," whereas the chapter uses a bound
  on gradient norms along the iterates.
- introduction.tex:44 states r = tilde-Theta(1), while the linear-mixing proof
  requires a lower bound of order tilde-Omega(1) and also uses r <= d.
- related_work.tex:18 says each worker stores O(rd) parameters in the matrix
  setting; the dense population storage described there appears to be O(rdm).
- conclusion.tex:29 says L-smoothness is "more general [than] a Lipschitz
  assumption." Function Lipschitzness and gradient Lipschitzness are different
  assumptions and should not be ordered this way without qualification.

### Preliminaries

- preliminaries.tex:79 identifies f-star with an argmin, mixing a function value
  with a point, and calls an O(1/epsilon) convex rate "linear convergence."
- preliminaries.tex:191--195 gives countable additivity without requiring the
  events to be pairwise disjoint. The missing P(E_i) notation was fixed, but the
  missing hypothesis was intentionally not added.
- preliminaries.tex:206--217 defines a filtration whose sampling/indexing
  convention is inconsistent with later claims that x_t and the gradient are
  measurable with respect to the previous sigma-algebra.
- preliminaries.tex:245 says the variance bound (b_i-a_i)^2 is tight up to
  constants while the extremal Bernoulli variance displayed immediately after
  it is (b_i-a_i)^2/4.
- preliminaries.tex:282--294 allows time-varying sigma_t in the adapted
  Hoeffding lemma but does not state that sigma_t is measurable with respect to
  the preceding filtration.

### Zeroth-order mirror descent

- mirror_conv.tex:145--174 reuses t as both an iteration index and an exponential
  scale, and the truncation/MGF calculation does not establish the stated
  uniform estimator bound. Conditioning was changed to the consistent
  filtration index, but the proof itself remains for review.
- mirror_conv.tex:187--218 asserts a conditional sub-Gaussian scale for Q_t
  without fully deriving it from the truncated product; the stated parameter
  also mixes variance-proxy and standard-deviation conventions.
- mirror_conv.tex:280--321 uses x-star, Theta, and chi in the final theorem
  without defining all of them in the theorem statement. The final displayed
  constant simplification is also algebraically inconsistent.
- mirror_conv.tex:321 says the extension is to the setting "without quadratic
  error"; the intended open case appears to be nonquadratic objectives, where
  the estimator has nonzero approximation error.

### EGGROLL convergence

- FOSP_eggroll.tex:69--79 gives the informal iteration requirement using
  T = tilde-Omega(...) rather than an upper complexity bound, and its parameter
  scales are not reconciled with the formal theorem.
- FOSP_eggroll.tex:113--180 states P(A) >= 1-delta, while the proof concludes
  only P(A) >= 1-C delta.
- FOSP_eggroll.tex:185--323 drops P(A_t)P(B_t) factors in the truncated-centering
  calculation but concludes that Q_t is centered. The later MGF argument uses a
  bound valid on B as though it were untruncated, and the displayed bound for
  ||Q_t||_F^2 lacks the usual squared second term and constants. The norm-
  sub-Gaussian claim is therefore not established.
- FOSP_eggroll.tex:484--520 asserts that centered squared bilinear Gaussian
  projections are sub-exponential without proving the tail class. It defines
  E_t as a low-progress event but computes its probability using the opposite
  high-progress event, and the iterated-conditioning display ends in
  exp(+c r k), which cannot imply delta/T. The quantity t_f is also real-valued
  but is later used as an integer block length.
- FOSP_eggroll.tex:623--650 has a one-step recurrence with factor
  1+1/(8t_f), but its proposed unrolling uses powers of 1-1/(8t_f).
- FOSP_eggroll.tex:653 onward assumes tau/t_f and then T/t_f are integers
  without handling nondivisible final blocks.
- In the function-change block calculation, the progress-event factor is lost
  between the lower bound on S_k and the claimed eta/4 decrease.
- In the main theorem, an eta/4 coefficient changes to eta/2 during the
  pigeonhole/decrease argument; the error budget and horizon constant are
  therefore unverified.
- The final probability calculation sums probabilities of success events
  A_t, G_t, and B_k rather than probabilities of their complements, so it does
  not bound the failure event.

### Zeroth-order linear mixing

- linear_mixing.tex:51, :64, :412, and :445 use inconsistent initialization:
  the algorithm lists x_0, y_0, z_0 but does not use x_0; theorem statements use
  f(x_0)-f-star while proofs use f(y_0)-f-star and V_{z_0}(x-star).
- linear_mixing.tex:67 says r = tilde-O(1), but the proof at :151 and :414
  requires r >= 16 chi. The displayed informal mixing ratio also disagrees with
  the later coupling choice.
- linear_mixing.tex:121 and :137 state an operator-event threshold proportional
  to d/r, while the proof derives one proportional to sqrt(d/r).
- linear_mixing.tex:207--212 assigns probability 1-delta/(rT) to an intersection
  over r directions, introduces an undefined gamma after Young's inequality,
  and uses a nonuniform logarithmic remainder bound.
- linear_mixing.tex:274 asserts the probability of the event G_{t+1} from a
  triangle inequality and a concentration lemma that do not establish the
  stated conditional Gaussian/operator event.
- linear_mixing.tex:281 and :293 omit the /r factor needed to match the
  coefficient used by the estimator-bound and regret statements.
- linear_mixing.tex:299--307 omits the estimator's 1/r factor in the martingale
  decomposition and uses the wrong sign for R_{t+1}. The event at :322 uses a
  free tau and inherits an inconsistent sqrt(Cr) scaling.
- linear_mixing.tex:345--362 has inconsistent /r factors and inconsistent
  martingale/remainder coefficients between the regret statement and proof.
- linear_mixing.tex:384--406 alternates between chi and chi-squared in the same
  Young-term calculation and omits the extra chi induced by gamma = 8 chi.
- linear_mixing.tex:427--434 changes 64 C d chi/(r eta) to
  64 C d chi-squared/(r eta) without derivation.
- linear_mixing.tex:478 concludes the restart sum with dependence on
  1/sqrt(Delta). The displayed geometric sum is dominated by its final stage
  and should depend on 1/sqrt(epsilon); hence the theorem at :481--487 is not
  derived as written.

## Spelling and obvious grammar findings left unchanged

These are findings, not applied edits.

- introduction.tex:9: deisgn -> design; acess -> access.
- introduction.tex:24: desecent -> descent.
- related_work.tex:5: algtorithms -> algorithms.
- related_work.tex:33: poweful -> powerful.
- related_work.tex:35: propogate -> propagate.
- related_work.tex:44 and :53: reguarlized -> regularized.
- related_work.tex:53: stochsatic -> stochastic; "However, the while" needs
  correction.
- related_work.tex:61: convegence -> convergence; prefe -> prefer.
- preliminaries.tex:4: assupmtions -> assumptions.
- preliminaries.tex:91: backpropogation -> backpropagation.
- FOSP_eggroll.tex:8: Stratregies -> Strategies; subject-verb agreement in
  "methods ... was scaled."
- FOSP_eggroll.tex:170: ths -> this.
- FOSP_eggroll.tex:216: indepedent -> independent.
- FOSP_eggroll.tex:613: satifies -> satisfies.
- mirror_conv.tex:6: iteravely -> iteratively.
- mirror_conv.tex:19: learing -> learning; reguarlized -> regularized.
- mirror_conv.tex:151: who's -> whose.
- mirror_conv.tex:269: minmizer -> minimizer.
- mirror_conv.tex:276: let's -> lets.
- mirror_conv.tex:321: anaslysis -> analysis; the "without quadratic error"
  wording conflicts with the preceding quadratic restriction.
- linear_mixing.tex:20: Unfortuantely -> Unfortunately; the sentence also misses
  "is" after "3=2+1."
- linear_mixing.tex:108: cannot possible -> cannot possibly; the finite-
  difference expression needs grouping for its denominator.
- linear_mixing.tex:476: "there is multiple minima" -> "there are multiple
  minima"; "it's original value" -> "its original value."
- linear_mixing.tex:488: "a L-smooth" -> "an L-smooth."
- conclusion.tex:5: dimenisons -> dimensions.
- conclusion.tex:8: realy -> really.
- conclusion.tex:11: "shown to rapidly escaping" -> "shown to rapidly escape."
- conclusion.tex:13: propogates -> propagates.

## Scope

The audit covers the active include tree of dissertation.tex. The standalone
EGGROLL_presentation.tex and learning_rate.tex are not included in the
dissertation build and were not reviewed.

